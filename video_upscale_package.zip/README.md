# Video Upscale Project (Render backend + Cloudflare Pages frontend)

Это готовый шаблон проекта для улучшения качества видео:
- Backend: Flask API (backend/) — принимает MP4 и "обрабатывает" (в шаблоне копирует файл).
- Frontend: простой React-like интерфейс на одной странице (frontend/index.html). Готов для хостинга на Cloudflare Pages.

## Как использовать

1. Залейте `backend` в репозиторий на GitHub.
2. На Render создайте Web Service, подключив этот репозиторий. Render использует `render.yaml`.
3. После деплоя замените `https://<YOUR_RENDER_SERVICE>.onrender.com` в `frontend/index.html` на URL вашего Render сервиса.
4. Залейте `frontend` репозиторий и разверните в Cloudflare Pages (или просто откройте index.html локально).

## Как подключить Real-ESRGAN (рекомендации)

- В `render.yaml` показаны комментарии с примером загрузки `realesrgan-ncnn-vulkan`.
- На Render вы можете модифицировать `buildCommand` чтобы установить необходимые зависимости и модели.
- Вместо симуляции (копирования файла) в `backend/main.py` раскомментируйте и используйте реальную команду `realesrgan-ncnn-vulkan` или ваш скрипт обработки.

## Особенности
- Этот шаблон **поддерживает только MP4** (для упрощения).
- Для продакшна рекомендую добавить:
  - асинхронную очередь задач (Celery / Redis),
  - аутентификацию и лимиты загрузки,
  - хранилище (Cloudflare R2) для файлов более 100MB.

Удачи! Если хочешь — я могу:
- добавить поддержку RIFE (интерполяция кадров),
- сделать frontend полноценным React/Vite проекту,
- подключить Cloudflare R2 и пример использования.
